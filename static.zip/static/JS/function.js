$(document).ready(function(){
    $('#delete').click(function(){
        $(".delete").toggle();
    });
});